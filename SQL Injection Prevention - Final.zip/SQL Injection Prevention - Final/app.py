import joblib
from flask import Flask, render_template, request

app = Flask(__name__)

# Load saved model and vectorizer
rf_model = joblib.load("models/rf_model.pkl")
tfidf_vectorizer = joblib.load("models/tfidf_vectorizer.pkl")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    query = request.form["query"]
    query_tfidf = tfidf_vectorizer.transform([query])
    prediction = rf_model.predict(query_tfidf)[0]
    result = "Malicious" if prediction == 1 else "Benign"
    return render_template("results.html", query=query, result=result)

if __name__ == "__main__":
    app.run(debug=True)
